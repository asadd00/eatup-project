<?php
require "db.php";


if(isset($_GET['area'])){
$sql = "SELECT name FROM areas";
$res = mysqli_query($con, $sql) or die(mysqli_error($con));

	
	if(mysqli_num_rows($res) > 0){
		$arr = array();
		header('Content-Type: application/json');
		while($row = mysqli_fetch_assoc($res)){
			$arr[] = $row;
		}
		$json_response = json_encode($arr);
		echo $json_response;
	}
		
}
?>