<?php

		if(isset($_POST['Submit']))
		{
		$user = $_POST['Username'];
		$id = $_POST['Email'];
		$pass = $_POST['Password'];
		$cPass = $_POST['Confirm_Password'];
		$conn = mysqli_connect("asad","asad","","eatup");
		if(!$conn){die("connection failed");}
		else {
			if(!empty($user)&&!empty($id)&&!empty($pass)){
				echo $user . $id . $pass . $cPass;
				if($pass == $cPass){
					$sql = "insert into registration (name,email,password) values('".$user."','".$id."','".$pass."')";
					$res = mysqli_query($conn, $sql) or die(mysqli_error($conn));
					if(!empty($res)){echo "<script>alert('Registratin successful!')</script>";}
					
				}else echo "<script>alert('Password missmatch!')</script>";
				
			
			}}
		} else echo 'error!';

?>