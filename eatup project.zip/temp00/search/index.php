
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Search</title>
  <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.1/themes/base/minified/jquery-ui.min.css" type="text/css" /> 
</head>
<body> 

    <h1>Search</h1>

	<input title="Start Typing to search Area" id="input"><b> </b>

	<button id="clickme" type="button" title="Search" value="Search">Search</button>

	<ul id="restaurants">
		
	</ul>

<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>    
<script type="text/javascript">

$(document).ready(function () {
    var areasJS = new Array;
    var data2 = new Array;

        $.ajax({
            url : "areas.php",
            method : "GET",
            data : {area : "area"},
            success : function(data2){
               
                for(var i = 0; i < data2.length; i++){
                    areasJS[i] = data2[i].name;
                }

                 $('#input').autocomplete({
                     source: areasJS
                });
            }
        });
});
</script>
</body>
</html>