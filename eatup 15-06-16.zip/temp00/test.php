<?php
			require "db.php";


		
		if(isset($_POST['bSearch'])){
			echo "done";
			$test = $_POST['tSearch'];
			

			$sql = "select res_name FROM restaurants where name='".$test."'";
			$result = mysqli_query($con,$sql);
			while($row = mysqli_fetch_assoc($result)){
				echo $row['res_name'];
			}
				
		}
		
		
		if(isset($_POST['confirm'])){
			echo 'order confirmed!';
		}
		
?>